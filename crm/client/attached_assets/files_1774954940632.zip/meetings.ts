import { Router } from "express";
import express from "express";
import { z } from "zod";
import { storage } from "../storage";
import { api } from "@shared/routes";
import { meetings } from "@shared/schema";
import { isAuthenticated } from "../replit_integrations/auth";
import { speechToText, ensureCompatibleFormat, openai } from "../replit_integrations/audio/client";
import { verifyClientOwnership, verifyFpRecordOwnership } from "./middleware";

export const meetingsRouter = Router();

const audioBodyParser = express.json({ limit: "50mb" });

// ── CRUD ──────────────────────────────────────────────────────────────────────

meetingsRouter.get("/:clientId/meetings", isAuthenticated, async (req: any, res) => {
  const clientId = Number(req.params.clientId);
  if (!(await verifyClientOwnership(req, res, clientId))) return;
  res.json(await storage.getMeetingsByClient(clientId));
});

meetingsRouter.post("/:clientId/meetings", isAuthenticated, async (req: any, res) => {
  try {
    const clientId = Number(req.params.clientId);
    if (!(await verifyClientOwnership(req, res, clientId))) return;
    const input = api.meetings.create.input
      .extend({ date: z.coerce.date() })
      .parse(req.body);
    res.status(201).json(await storage.createMeeting({ ...input, clientId }));
  } catch (err) {
    if (err instanceof z.ZodError) {
      return res.status(400).json({
        message: err.errors[0].message,
        field: err.errors[0].path.join("."),
      });
    }
    throw err;
  }
});

// ── Audio upload (legacy path) ────────────────────────────────────────────────

meetingsRouter.post("/:id/audio", isAuthenticated, audioBodyParser, async (req: any, res) => {
  try {
    const id = Number(req.params.id);
    if (!(await verifyFpRecordOwnership(req, res, meetings, id))) return;
    const { audio } = req.body;
    if (!audio) return res.status(400).json({ message: "Audio data required" });
    const meeting = await storage.getMeeting(id);
    if (!meeting) return res.status(404).json({ message: "Meeting not found" });
    const rawBuffer = Buffer.from(audio, "base64");
    const { buffer: audioBuffer, format: inputFormat } = await ensureCompatibleFormat(rawBuffer);
    const transcript = await speechToText(audioBuffer, inputFormat);
    const completion = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "Summarize this client meeting transcript for a financial advisor's notes. Extract key action items and decisions.",
        },
        { role: "user", content: transcript },
      ],
    });
    const summary = completion.choices[0].message.content || "";
    res.json(await storage.updateMeeting(id, { transcript, summary }));
  } catch (err) {
    console.error("Audio processing error:", err);
    res.status(500).json({ message: "Failed to process audio" });
  }
});

// ── Recall.ai bot ─────────────────────────────────────────────────────────────

meetingsRouter.post("/:id/send-notetaker", isAuthenticated, async (req: any, res) => {
  try {
    const id = Number(req.params.id);
    if (!(await verifyFpRecordOwnership(req, res, meetings, id))) return;
    const meeting = await storage.getMeeting(id);
    if (!meeting) return res.status(404).json({ message: "Meeting not found" });
    const staffRecord = await storage.getStaffMember(req.session.staffId);
    if (!staffRecord) return res.status(403).json({ message: "Staff not found" });
    const company = await storage.getCompany(staffRecord.companyId);
    if (!company?.moduleMeetingRecorder) {
      return res.status(403).json({ message: "Meeting Recorder module is not enabled" });
    }
    const meetingUrl = req.body.meetingUrl || meeting.meetingJoinUrl;
    if (!meetingUrl) {
      return res.status(400).json({
        message: "No meeting URL available. Provide a meetingUrl in the request body or ensure the meeting has a join URL.",
      });
    }
    if (meeting.recallBotId && meeting.recordingStatus !== "error") {
      return res.status(409).json({ message: "A notetaker is already active for this meeting" });
    }
    if (!process.env.RECALL_API_KEY) {
      return res.status(503).json({
        message: "Meeting recording service is not configured. Please contact your administrator.",
      });
    }
    const { createRecallBot, mapRecallStatusToRecordingStatus } = await import("../services/recall");
    const bot = await createRecallBot({
      meetingUrl,
      botName: req.body.botName || "FinAdvisor Notetaker",
    });
    const platform = meetingUrl.includes("teams.microsoft.com")
      ? "teams"
      : meetingUrl.includes("zoom.us")
        ? "zoom"
        : meetingUrl.includes("meet.google.com")
          ? "google_meet"
          : "other";
    res.json(
      await storage.updateMeeting(id, {
        recallBotId: bot.id,
        recordingStatus: mapRecallStatusToRecordingStatus(bot.status.code),
        meetingJoinUrl: meetingUrl,
        platform,
      })
    );
  } catch (err: unknown) {
    console.error("Send notetaker error:", err);
    res.status(500).json({ message: err instanceof Error ? err.message : "Failed to send notetaker" });
  }
});

meetingsRouter.get("/:id/recording-status", isAuthenticated, async (req: any, res) => {
  try {
    const id = Number(req.params.id);
    if (!(await verifyFpRecordOwnership(req, res, meetings, id))) return;
    const meeting = await storage.getMeeting(id);
    if (!meeting) return res.status(404).json({ message: "Meeting not found" });
    if (
      meeting.recallBotId &&
      meeting.recordingStatus !== "done" &&
      meeting.recordingStatus !== "error"
    ) {
      try {
        const { getRecallBotStatus, mapRecallStatusToRecordingStatus } = await import("../services/recall");
        const bot = await getRecallBotStatus(meeting.recallBotId);
        const newStatus = mapRecallStatusToRecordingStatus(bot.status.code);
        if (newStatus !== meeting.recordingStatus) {
          await storage.updateMeeting(id, { recordingStatus: newStatus, recordingUrl: bot.video_url || undefined });
        }
        return res.json({ recordingStatus: newStatus, recordingUrl: bot.video_url || null });
      } catch {
        return res.json({ recordingStatus: meeting.recordingStatus, recordingUrl: meeting.recordingUrl });
      }
    }
    res.json({ recordingStatus: meeting.recordingStatus || "none", recordingUrl: meeting.recordingUrl });
  } catch (err) {
    console.error("Recording status error:", err);
    res.status(500).json({ message: "Failed to fetch recording status" });
  }
});

// ── AI outputs ────────────────────────────────────────────────────────────────

meetingsRouter.get("/:id/outputs", isAuthenticated, async (req: any, res) => {
  try {
    const id = Number(req.params.id);
    if (!(await verifyFpRecordOwnership(req, res, meetings, id))) return;
    const outputs = await storage.getMeetingOutputs(id);
    if (!outputs) return res.status(404).json({ message: "No AI outputs found for this meeting" });
    res.json(outputs);
  } catch (err) {
    console.error("Meeting outputs error:", err);
    res.status(500).json({ message: "Failed to fetch meeting outputs" });
  }
});

meetingsRouter.get("/:id/transcript", isAuthenticated, async (req: any, res) => {
  try {
    const id = Number(req.params.id);
    if (!(await verifyFpRecordOwnership(req, res, meetings, id))) return;
    const transcript = await storage.getMeetingTranscript(id);
    if (!transcript) return res.status(404).json({ message: "No transcript found" });
    res.json(transcript);
  } catch (err) {
    console.error("Meeting transcript error:", err);
    res.status(500).json({ message: "Failed to fetch transcript" });
  }
});

meetingsRouter.post("/:id/outputs/review-compliance", isAuthenticated, async (req: any, res) => {
  try {
    const id = Number(req.params.id);
    if (!(await verifyFpRecordOwnership(req, res, meetings, id))) return;
    const outputs = await storage.getMeetingOutputs(id);
    if (!outputs) return res.status(404).json({ message: "No outputs to review" });
    res.json(
      await storage.updateMeetingOutputs(outputs.id, {
        complianceReviewed: true,
        complianceReviewedBy: req.session.staffId,
        complianceReviewedAt: new Date(),
      })
    );
  } catch (err) {
    console.error("Compliance review error:", err);
    res.status(500).json({ message: "Failed to review compliance" });
  }
});

// ── Tasks ─────────────────────────────────────────────────────────────────────

meetingsRouter.get("/:meetingId/tasks", isAuthenticated, async (req: any, res) => {
  try {
    const meetingId = Number(req.params.meetingId);
    if (!(await verifyFpRecordOwnership(req, res, meetings, meetingId))) return;
    res.json(await storage.getMeetingTasks(meetingId));
  } catch (err) {
    console.error("Meeting tasks error:", err);
    res.status(500).json({ message: "Failed to fetch meeting tasks" });
  }
});

meetingsRouter.patch("/:meetingId/tasks/:taskId", isAuthenticated, async (req: any, res) => {
  try {
    const meetingId = Number(req.params.meetingId);
    if (!(await verifyFpRecordOwnership(req, res, meetings, meetingId))) return;
    const taskId = Number(req.params.taskId);
    const task = await storage.getMeetingTask(taskId);
    if (!task || task.meetingId !== meetingId) {
      return res.status(404).json({ message: "Task not found" });
    }
    const { status } = req.body;
    const updates: Record<string, unknown> = {};
    if (status) updates.status = status;
    if (status === "complete") updates.completedAt = new Date();
    res.json(await storage.updateMeetingTask(taskId, updates));
  } catch (err) {
    console.error("Meeting task update error:", err);
    res.status(500).json({ message: "Failed to update meeting task" });
  }
});

// ── Consent ───────────────────────────────────────────────────────────────────

meetingsRouter.get("/:id/consent", isAuthenticated, async (req: any, res) => {
  try {
    const meetingId = Number(req.params.id);
    if (!(await verifyFpRecordOwnership(req, res, meetings, meetingId))) return;
    res.json((await storage.getMeetingConsent(meetingId)) || null);
  } catch (err) {
    console.error("Get consent error:", err);
    res.status(500).json({ message: "Failed to fetch consent" });
  }
});

meetingsRouter.post("/:id/consent", isAuthenticated, async (req: any, res) => {
  try {
    const meetingId = Number(req.params.id);
    if (!(await verifyFpRecordOwnership(req, res, meetings, meetingId))) return;
    const { consentMethod, notes } = req.body;
    const meeting = await storage.getMeeting(meetingId);
    if (!meeting) return res.status(404).json({ message: "Meeting not found" });
    const staffId = req.session.staffId as number;
    res.status(201).json(
      await storage.createMeetingConsent({
        meetingId,
        clientId: meeting.clientId,
        consentMethod: consentMethod || "verbal",
        verbalCertifiedBy: consentMethod === "verbal" ? staffId : undefined,
        ipAddress: req.ip || undefined,
        notes,
      })
    );
  } catch (err) {
    console.error("Create consent error:", err);
    res.status(500).json({ message: "Failed to record consent" });
  }
});

// ── In-app recording chunks ───────────────────────────────────────────────────

meetingsRouter.post("/:id/chunks", isAuthenticated, async (req: any, res) => {
  try {
    const meetingId = Number(req.params.id);
    if (!(await verifyFpRecordOwnership(req, res, meetings, meetingId))) return;
    const consent = await storage.getMeetingConsent(meetingId);
    if (!consent || consent.consentRevokedAt) {
      return res.status(403).json({ message: "Recording consent is required" });
    }
    const { chunkIndex, audioData, sizeBytes } = req.body;
    if (typeof chunkIndex !== "number" || !audioData) {
      return res.status(400).json({ message: "Missing chunkIndex or audioData" });
    }
    const chunk = await storage.createRecordingChunk({
      meetingId,
      chunkIndex,
      audioData,
      sizeBytes: sizeBytes || 0,
    });
    if (chunkIndex === 0) {
      await storage.updateMeeting(meetingId, { recordingStatus: "recording" });
    }
    res.status(201).json({ id: chunk.id, chunkIndex: chunk.chunkIndex });
  } catch (err) {
    console.error("Chunk upload error:", err);
    res.status(500).json({ message: "Failed to upload chunk" });
  }
});

meetingsRouter.post("/:id/recording/complete", isAuthenticated, async (req: any, res) => {
  try {
    const meetingId = Number(req.params.id);
    if (!(await verifyFpRecordOwnership(req, res, meetings, meetingId))) return;
    await storage.updateMeeting(meetingId, { recordingStatus: "processing" });
    const consent = await storage.getMeetingConsent(meetingId);
    if (!consent || consent.consentRevokedAt) {
      return res.status(403).json({ message: "Recording consent is required before processing" });
    }
    const chunks = await storage.getRecordingChunks(meetingId);
    if (chunks.length === 0) {
      return res.status(400).json({ message: "No recording chunks found" });
    }
    const binaryChunks = chunks.map(c => Buffer.from(c.audioData, "base64"));
    const audioBuffer = Buffer.concat(binaryChunks);
    const audioFile = new File([audioBuffer], "recording.webm", { type: "audio/webm" });
    const whisperResponse = await openai.audio.transcriptions.create({
      file: audioFile,
      model: "whisper-1",
      language: "en",
      response_format: "verbose_json",
      timestamp_granularities: ["segment"],
    });
    const segments = (whisperResponse.segments || []).map(
      (seg: { start: number; end: number; text: string }, idx: number) => ({
        speaker: idx % 2 === 0 ? "Speaker 1" : "Speaker 2",
        start: seg.start,
        end: seg.end,
        text: seg.text.trim(),
      })
    );
    const fullText = segments
      .map((s: { speaker: string; text: string }) => `${s.speaker}: ${s.text}`)
      .join("\n");
    const wordCount = fullText.split(/\s+/).filter(Boolean).length;
    const existingTranscript = await storage.getMeetingTranscript(meetingId);
    if (!existingTranscript) {
      await storage.createMeetingTranscript({
        meetingId,
        segments,
        fullText,
        language: "en-CA",
        wordCount,
      });
    }
    await storage.updateMeeting(meetingId, { transcript: fullText, recordingStatus: "processing" });
    await storage.deleteRecordingChunks(meetingId);
    try {
      const { processMeetingIntelligence } = await import("../services/meeting-intelligence");
      await processMeetingIntelligence(meetingId);
    } catch (aiErr) {
      console.error(`AI processing failed for meeting ${meetingId}:`, aiErr);
      await storage.updateMeeting(meetingId, { recordingStatus: "error" });
    }
    res.json({ message: "Recording processed", wordCount });
  } catch (err) {
    console.error("Recording complete error:", err);
    await storage.updateMeeting(Number(req.params.id), { recordingStatus: "error" }).catch(() => {});
    res.status(500).json({ message: "Failed to process recording" });
  }
});

// ── Recall webhook ────────────────────────────────────────────────────────────

meetingsRouter.post("/webhooks/recall", express.json(), async (req, res) => {
  try {
    const webhookSecret = process.env.RECALL_WEBHOOK_SECRET;
    if (webhookSecret) {
      const providedToken = req.headers["x-recall-webhook-secret"] || req.query.secret;
      if (providedToken !== webhookSecret) {
        return res.status(401).json({ message: "Invalid webhook secret" });
      }
    }
    const { event, data } = req.body;
    if (!data?.bot_id) return res.status(400).json({ message: "Missing bot_id" });
    const meeting = await storage.getMeetingByRecallBotId(data.bot_id);
    if (!meeting) {
      console.log(`Recall webhook: no meeting found for bot ${data.bot_id}`);
      return res.status(200).json({ message: "ok" });
    }
    const { mapRecallStatusToRecordingStatus } = await import("../services/recall");
    if (event === "bot.status_change") {
      const newStatus = mapRecallStatusToRecordingStatus(data.status?.code || "");
      await storage.updateMeeting(meeting.id, { recordingStatus: newStatus });
      if (data.status?.code === "done" || data.status?.code === "analysis_done") {
        const existingTranscript = await storage.getMeetingTranscript(meeting.id);
        if (existingTranscript) {
          return res.status(200).json({ message: "ok (duplicate)" });
        }
        try {
          const {
            getRecallBotTranscript,
            getRecallRecordingUrl,
            formatRecallTranscript,
          } = await import("../services/recall");
          const [rawTranscript, recordingUrl] = await Promise.all([
            getRecallBotTranscript(data.bot_id),
            getRecallRecordingUrl(data.bot_id),
          ]);
          const { structured, fullText } = formatRecallTranscript(rawTranscript);
          const wordCount = fullText.split(/\s+/).filter(Boolean).length;
          await storage.createMeetingTranscript({
            meetingId: meeting.id,
            segments: structured,
            fullText,
            language: "en-CA",
            wordCount,
          });
          await storage.updateMeeting(meeting.id, {
            recordingUrl: recordingUrl || undefined,
            recordingStatus: "processing",
          });
          const { processMeetingIntelligence } = await import("../services/meeting-intelligence");
          await processMeetingIntelligence(meeting.id);
        } catch (processErr) {
          console.error(`Recall webhook: failed to process meeting ${meeting.id}:`, processErr);
          await storage.updateMeeting(meeting.id, { recordingStatus: "error" });
        }
      }
    }
    res.status(200).json({ message: "ok" });
  } catch (err) {
    console.error("Recall webhook error:", err);
    res.status(500).json({ message: "Webhook processing failed" });
  }
});
