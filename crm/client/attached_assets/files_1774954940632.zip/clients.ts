import { Router } from "express";
import { z } from "zod";
import { storage } from "../storage";
import { api } from "@shared/routes";
import { children, documents, activities } from "@shared/schema";
import { isAuthenticated } from "../replit_integrations/auth";
import {
  getStaffFromSession, getCompanyId,
  verifyClientOwnership, verifyFpRecordOwnership,
} from "./middleware";

export const clientsRouter = Router();

// ── Clients ───────────────────────────────────────────────────────────────────

clientsRouter.get("/", isAuthenticated, async (req: any, res) => {
  const currentStaff = await getStaffFromSession(req);
  const companyId = currentStaff?.companyId ?? undefined;
  if (!currentStaff) {
    return res.json(await storage.getClients(companyId));
  }
  if (currentStaff.role === "advisor") {
    return res.json(await storage.getClientsByAdvisor(currentStaff.id));
  }
  if (currentStaff.role === "advisor_admin" || currentStaff.role === "sales_manager") {
    const myAdvisors = await storage.getAdvisorsByAdmin(currentStaff.id);
    const advisorIds = [currentStaff.id, ...myAdvisors.map(a => a.id)];
    return res.json(await storage.getClientsByAdvisors(advisorIds));
  }
  res.json(await storage.getClients(companyId));
});

clientsRouter.get("/:id", isAuthenticated, async (req: any, res) => {
  const clientId = Number(req.params.id);
  if (!(await verifyClientOwnership(req, res, clientId))) return;
  const client = await storage.getClient(clientId);
  if (!client) return res.status(404).json({ message: "Client not found" });
  res.json(client);
});

clientsRouter.post("/", isAuthenticated, async (req: any, res) => {
  try {
    const input = api.clients.create.input
      .extend({
        advisorId: z.coerce.number().optional().nullable(),
        spouseId: z.coerce.number().optional().nullable(),
      })
      .parse(req.body);
    const companyId = await getCompanyId(req);
    const client = await storage.createClient({ ...input, companyId });
    if (client.spouseId) {
      await storage.updateClient(client.spouseId, { spouseId: client.id });
    }
    res.status(201).json(client);
  } catch (err) {
    if (err instanceof z.ZodError) {
      return res.status(400).json({
        message: err.errors[0].message,
        field: err.errors[0].path.join("."),
      });
    }
    throw err;
  }
});

clientsRouter.put("/:id", isAuthenticated, async (req: any, res) => {
  try {
    const clientId = Number(req.params.id);
    if (!(await verifyClientOwnership(req, res, clientId))) return;
    const existing = await storage.getClient(clientId);
    if (!existing) return res.status(404).json({ message: "Client not found" });
    const input = api.clients.update.input.parse(req.body);
    const oldSpouseId = existing.spouseId;
    const newSpouseId = input.spouseId !== undefined ? input.spouseId : oldSpouseId;
    const client = await storage.updateClient(clientId, input);
    if (oldSpouseId !== newSpouseId) {
      if (oldSpouseId) await storage.updateClient(oldSpouseId, { spouseId: null });
      if (newSpouseId) {
        const newSpouse = await storage.getClient(newSpouseId);
        if (newSpouse?.spouseId && newSpouse.spouseId !== clientId) {
          await storage.updateClient(newSpouse.spouseId, { spouseId: null });
        }
        await storage.updateClient(newSpouseId, { spouseId: clientId });
      }
    }
    res.json(client);
  } catch (err) {
    if (err instanceof z.ZodError) {
      return res.status(400).json({
        message: err.errors[0].message,
        field: err.errors[0].path.join("."),
      });
    }
    throw err;
  }
});

// ── Children ──────────────────────────────────────────────────────────────────

clientsRouter.get("/:clientId/children", isAuthenticated, async (req: any, res) => {
  const clientId = Number(req.params.clientId);
  if (!(await verifyClientOwnership(req, res, clientId))) return;
  res.json(await storage.getChildrenByClient(clientId));
});

clientsRouter.post("/:clientId/children", isAuthenticated, async (req: any, res) => {
  try {
    const clientId = Number(req.params.clientId);
    if (!(await verifyClientOwnership(req, res, clientId))) return;
    const input = api.children.create.input.parse(req.body);
    res.status(201).json(await storage.createChild({ ...input, clientId }));
  } catch (err) {
    if (err instanceof z.ZodError) {
      return res.status(400).json({
        message: err.errors[0].message,
        field: err.errors[0].path.join("."),
      });
    }
    throw err;
  }
});

clientsRouter.put("/:clientId/children/:id", isAuthenticated, async (req: any, res) => {
  try {
    const id = Number(req.params.id);
    if (!(await verifyFpRecordOwnership(req, res, children, id))) return;
    const input = api.children.update.input.parse(req.body);
    const child = await storage.updateChild(id, input);
    if (!child) return res.status(404).json({ message: "Child not found" });
    res.json(child);
  } catch (err) {
    if (err instanceof z.ZodError) {
      return res.status(400).json({
        message: err.errors[0].message,
        field: err.errors[0].path.join("."),
      });
    }
    throw err;
  }
});

clientsRouter.delete("/:clientId/children/:id", isAuthenticated, async (req: any, res) => {
  const id = Number(req.params.id);
  if (!(await verifyFpRecordOwnership(req, res, children, id))) return;
  await storage.deleteChild(id);
  res.status(204).send();
});

// ── Documents ─────────────────────────────────────────────────────────────────

clientsRouter.get("/:clientId/documents", isAuthenticated, async (req: any, res) => {
  const clientId = Number(req.params.clientId);
  if (!(await verifyClientOwnership(req, res, clientId))) return;
  res.json(await storage.getDocumentsByClient(clientId));
});

clientsRouter.post("/:clientId/documents", isAuthenticated, async (req: any, res) => {
  try {
    const clientId = Number(req.params.clientId);
    if (!(await verifyClientOwnership(req, res, clientId))) return;
    const input = api.documents.create.input.parse(req.body);
    res.status(201).json(await storage.createDocument({ ...input, clientId }));
  } catch (err) {
    if (err instanceof z.ZodError) {
      return res.status(400).json({
        message: err.errors[0].message,
        field: err.errors[0].path.join("."),
      });
    }
    throw err;
  }
});

clientsRouter.put("/:clientId/documents/:id", isAuthenticated, async (req: any, res) => {
  try {
    const id = Number(req.params.id);
    if (!(await verifyFpRecordOwnership(req, res, documents, id))) return;
    const input = api.documents.update.input.parse(req.body);
    const doc = await storage.updateDocument(id, input);
    if (!doc) return res.status(404).json({ message: "Document not found" });
    res.json(doc);
  } catch (err) {
    if (err instanceof z.ZodError) {
      return res.status(400).json({
        message: err.errors[0].message,
        field: err.errors[0].path.join("."),
      });
    }
    throw err;
  }
});

clientsRouter.delete("/:clientId/documents/:id", isAuthenticated, async (req: any, res) => {
  const id = Number(req.params.id);
  if (!(await verifyFpRecordOwnership(req, res, documents, id))) return;
  await storage.deleteDocument(id);
  res.status(204).send();
});

// ── Activities ────────────────────────────────────────────────────────────────

clientsRouter.get("/:clientId/activities", isAuthenticated, async (req: any, res) => {
  const clientId = Number(req.params.clientId);
  if (!(await verifyClientOwnership(req, res, clientId))) return;
  res.json(await storage.getActivitiesByClient(clientId));
});

clientsRouter.post("/:clientId/activities", isAuthenticated, async (req: any, res) => {
  try {
    const clientId = Number(req.params.clientId);
    if (!(await verifyClientOwnership(req, res, clientId))) return;
    const input = api.activities.create.input
      .extend({ date: z.coerce.date() })
      .parse(req.body);
    res.status(201).json(await storage.createActivity({ ...input, clientId }));
  } catch (err) {
    if (err instanceof z.ZodError) {
      return res.status(400).json({
        message: err.errors[0].message,
        field: err.errors[0].path.join("."),
      });
    }
    throw err;
  }
});

clientsRouter.delete("/:clientId/activities/:id", isAuthenticated, async (req: any, res) => {
  const id = Number(req.params.id);
  if (!(await verifyFpRecordOwnership(req, res, activities, id))) return;
  await storage.deleteActivity(id);
  res.status(204).send();
});

// ── Products ──────────────────────────────────────────────────────────────────

clientsRouter.get("/:clientId/products", isAuthenticated, async (req: any, res) => {
  const clientId = Number(req.params.clientId);
  if (!(await verifyClientOwnership(req, res, clientId))) return;
  res.json(await storage.getProductsByClient(clientId));
});

clientsRouter.post("/:clientId/products", isAuthenticated, async (req: any, res) => {
  try {
    const clientId = Number(req.params.clientId);
    if (!(await verifyClientOwnership(req, res, clientId))) return;
    const input = api.products.create.input
      .extend({ value: z.coerce.string() })
      .parse(req.body);
    const caller = await getStaffFromSession(req);
    if (caller?.companyId) {
      const company = await storage.getCompany(caller.companyId);
      if (company) {
        const typeModuleMap: Record<
          string,
          "moduleInsurance" | "moduleMutualFund" | "moduleSegFund"
        > = {
          insurance: "moduleInsurance",
          mutual_fund: "moduleMutualFund",
          segregated_fund: "moduleSegFund",
        };
        const moduleKey = typeModuleMap[input.type];
        if (moduleKey && company[moduleKey] === false) {
          return res.status(403).json({
            message: `The ${input.type.replace("_", " ")} module is disabled for your company. Contact your General Manager to enable it.`,
          });
        }
      }
    }
    const allCarriers = await storage.getCarriers();
    const matchedCarrier = allCarriers.find(
      c => c.name.toLowerCase() === input.provider.toLowerCase()
    );
    if (!matchedCarrier) {
      return res.status(400).json({
        message: `Unknown carrier "${input.provider}". Must match a carrier in the system.`,
      });
    }
    if (matchedCarrier.type !== input.type) {
      return res.status(400).json({
        message: `Carrier "${input.provider}" is a ${matchedCarrier.type.replace("_", " ")} carrier, not ${input.type.replace("_", " ")}`,
      });
    }
    if (caller) {
      const advisorCarriers = await storage.getAdvisorCarriers(caller.id);
      if (!advisorCarriers.some(ac => ac.carrierId === matchedCarrier.id)) {
        return res.status(400).json({
          message: `Carrier "${input.provider}" is not in your selected carriers. Add it in Settings first.`,
        });
      }
    }
    res.status(201).json(await storage.createProduct({ ...input, clientId }));
  } catch (err) {
    if (err instanceof z.ZodError) {
      return res.status(400).json({
        message: err.errors[0].message,
        field: err.errors[0].path.join("."),
      });
    }
    throw err;
  }
});
