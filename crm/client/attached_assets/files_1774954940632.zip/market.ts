import { Router } from "express";
import { isAuthenticated } from "../replit_integrations/auth";

export const marketRouter = Router();

const FUND_SYMBOLS = [
  { symbol: "RBF1015.TO", name: "RBC Canadian Dividend" },
  { symbol: "TDB900.TO", name: "TD Canadian Index" },
  { symbol: "CIB509.TO", name: "CI Canadian Equity" },
  { symbol: "MFC856.TO", name: "Manulife Dividend Income" },
  { symbol: "IGI621.TO", name: "IG Mackenzie Growth" },
  { symbol: "FID683.TO", name: "Fidelity Canadian Asset" },
];

const STOCK_SYMBOLS = [
  { symbol: "RY.TO", name: "Royal Bank" },
  { symbol: "TD.TO", name: "TD Bank" },
  { symbol: "ENB.TO", name: "Enbridge" },
  { symbol: "CNR.TO", name: "CN Rail" },
  { symbol: "SU.TO", name: "Suncor" },
  { symbol: "BCE.TO", name: "BCE Inc" },
  { symbol: "BMO.TO", name: "BMO Financial" },
  { symbol: "BNS.TO", name: "Scotiabank" },
];

interface MarketQuoteCache {
  data: Array<{ symbol: string; name: string; price: number; change: number; changePercent: number }>;
  timestamp: number;
}

const marketCache: Record<string, MarketQuoteCache> = {};
const CACHE_TTL = 5 * 60 * 1000;

marketRouter.get("/quotes", isAuthenticated, async (req: any, res) => {
  try {
    const type = req.query.type === "stocks" ? "stocks" : "funds";
    if (marketCache[type] && Date.now() - marketCache[type].timestamp < CACHE_TTL) {
      return res.json(marketCache[type].data);
    }
    const symbols = type === "stocks" ? STOCK_SYMBOLS : FUND_SYMBOLS;
    const yahooFinance = (await import("yahoo-finance2")).default;
    const results: MarketQuoteCache["data"] = [];
    let successCount = 0;
    for (const entry of symbols) {
      try {
        const quote = await yahooFinance.quote(entry.symbol);
        if (quote.regularMarketPrice != null) {
          results.push({
            symbol: entry.symbol, name: entry.name,
            price: quote.regularMarketPrice,
            change: quote.regularMarketChange ?? 0,
            changePercent: quote.regularMarketChangePercent ?? 0,
          });
          successCount++;
        }
      } catch { /* skip failed symbols */ }
    }
    if (successCount === 0) {
      return res.status(503).json({ message: "Market data unavailable" });
    }
    marketCache[type] = { data: results, timestamp: Date.now() };
    res.json(results);
  } catch {
    res.status(500).json({ message: "Failed to fetch market data" });
  }
});
